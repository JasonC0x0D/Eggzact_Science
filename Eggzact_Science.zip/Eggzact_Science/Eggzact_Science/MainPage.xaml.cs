﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.Maker.RemoteWiring;
using Microsoft.Maker.Serial;

namespace Eggzact_Science
{
    /// <summary>
    /// The Main page that "hosts" the other pages inside of it.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            ContentFrame.Navigate(typeof(HomePage)); // Load the homepage on startup.
            
        }

        // The buttons load the corresponding pages in the frame on the main page.

        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(typeof(HomePage));
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(typeof(ConnectPage));
        }

        private void EggOverviewButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(typeof(EggOverviewPage));
        }

        // This button is hidden as there is no funciontality of the EggDetailPage yet.
        private void EggDetailButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(typeof(EggDetailPage));
        }
    }
}
