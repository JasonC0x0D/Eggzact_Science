﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


namespace Eggzact_Science
{
    /// <summary>
    /// This page will display the overall number of eggs waiting for collection.
    /// </summary>
    public sealed partial class EggOverviewPage : Page
    {
        public EggOverviewPage()
        {
            this.InitializeComponent();
        }

        private async void CheckForEggs_Click(object sender, RoutedEventArgs e)
        {
            Egg myEgg = await GetData();
            if (myEgg.NumberOfEggs == -1)
            {
                // There was an error so state that.
                Result.Text = "Error - There was a problem connecting to the Arduino.";
            }
            else
            {
                // No errors so display the number of eggs counted.
                Result.Text = "There are " + myEgg.NumberOfEggs + " eggs waiting for collection.";
            }
            
        }

        /// <summary>
        /// Gets the egg related data from the Arduino MKR 1000 from the webserver it is hosting .
        /// </summary>
        /// <returns> The overall Number of Eggs counted. (May be expanded in the future.) </returns>
        public async static Task<Egg> GetData()
        {
            // TODO - Grab the IP Address from the Connection Page.  Should look someothing like the line below.
            //        var response = await http.GetAsync("http//" + App.IPAddress + "/");

            var http = new HttpClient();

            try
            {
                var response = await http.GetAsync("http://192.168.1.6/"); // Hardcoded for now.                 
                // NOTE: MKR1000 server hosts the data as a JSON string which is how this program reads it.
                string result = await response.Content.ReadAsStringAsync();
                var serializer = new DataContractJsonSerializer(typeof(Egg));
                var ms = new MemoryStream(Encoding.UTF8.GetBytes(result));
                var data = (Egg)serializer.ReadObject(ms);
                return data;
            }
            catch  // Catches all exceptions in the code above. Returns number of eggs as -1 which signals there was an error. 
            {
                Egg fail = new Egg();
                fail.NumberOfEggs = -1;
                return fail;
            }       
        }

        public class Egg
        {
            public int NumberOfEggs { get; set; }
            // TODO - add more features like EggID, LayTime, HenID
            //      - may have a collection class (EggBasket) in the future that 
            //        holds a bunch of eggs or something like that.
        }
    }
}
