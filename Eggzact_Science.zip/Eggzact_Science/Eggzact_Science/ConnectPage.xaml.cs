﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.Maker.Serial;
using Microsoft.Maker.RemoteWiring;
using System.Net.Http;
using System.Threading.Tasks;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Eggzact_Science
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ConnectPage : Page
    {
        public ConnectPage()
        {
            this.InitializeComponent();

        }


        // This just saves the IP Address of the Arduino web server for later use.
        private async void SaveConnectData(object sender, RoutedEventArgs e)
        {
            // Show the connecting Progress Ring everyone loves!
            ConnectingPanel.Visibility = Visibility.Visible;
            ConnectionProgressRing.IsActive = true;

            // A delay to show this cool feature off.
            await Task.Delay(5000);
            App.IPAddress = IPAddressTextBox.Text;

            // Hide the connecting Progress Ring everyone loves!
            ConnectingPanel.Visibility = Visibility.Collapsed;
            ConnectionProgressRing.IsActive = false;
        }

        private void StackPanel_Loaded(object sender, RoutedEventArgs e)
        {
            IPAddressTextBox.Text = App.IPAddress;
        }
    }
}
