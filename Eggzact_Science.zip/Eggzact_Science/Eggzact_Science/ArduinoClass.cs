﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.Maker.Serial;
using Microsoft.Maker.RemoteWiring;

namespace Eggzact_Science
{

    class ArduinoClass
    {
        // Creating these fields to be used / filled later.
        Microsoft.Maker.Serial.NetworkSerial netWorkSerial;
        Microsoft.Maker.RemoteWiring.RemoteDevice arduino;

        public string IpAddress { get; set; }
        public ushort Port { get; set; }

        public void ConnectToArduino()
        {
            //Establish a network serial connection.
            netWorkSerial = new Microsoft.Maker.Serial.NetworkSerial(new Windows.Networking.HostName(this.IpAddress), this.Port);

            //Create Arduino Device
            arduino = new Microsoft.Maker.RemoteWiring.RemoteDevice(netWorkSerial);

            //Attach event handlers
            netWorkSerial.ConnectionEstablished += NetWorkSerial_ConnectionEstablished;
            netWorkSerial.ConnectionFailed += NetWorkSerial_ConnectionFailed;

            //Begin connection
            netWorkSerial.begin(115200, Microsoft.Maker.Serial.SerialConfig.SERIAL_8N1);

        }

        private void NetWorkSerial_ConnectionEstablished()
        {
            /*
            Arduino.pinMode(6, Microsoft.Maker.RemoteWiring.PinMode.OUTPUT); //Set the pin to output

            //turn it to High. The RED LED on Arduino Yun should light up
            Arduino.digitalWrite(6, Microsoft.Maker.RemoteWiring.PinState.HIGH);

            var action = Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, new Windows.UI.Core.DispatchedHandler(() =>
            {
                OnButton.IsEnabled = true;
                OffButton.IsEnabled = true;
            }));
            */

            App.ConnectionStatus = true;
            //ConnectionStatusTextBox.Text = "Connected";
            //ConnectPage.ConnectingPanel.Visibility = Visibility.Collapsed;
            //ConnectionProgressRing.IsActive = false;
        }

        private void NetWorkSerial_ConnectionFailed(string message)
        {
            // Display the error message for why connection failed.
            System.Diagnostics.Debug.WriteLine("Arduino Connection Failed: " + message);
            //ConnectionErrorBox.Visibility = Visibility.Visible;
            //ConnectionErrorBox.Text = message;

            // Set connection status to false
            App.ConnectionStatus = false;

            // Display connection status as error
            //ConnectionStatusTextBox.Text = "Error - Not Connected";

            // Hide the ring and connecting message.
            //ConnectingPanel.Visibility = Visibility.Collapsed;
            //ConnectionProgressRing.IsActive = false;
        }

    }
}
